package Project_Intranet;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import java.util.Scanner;
import java.util.TreeMap;

interface MENUNUM1 {
	String SEARCH = "1", ASK = "2", EXIT = "3";
}

interface SEARCHINFO_SELECT1 {
	String CALENDER = "1", DATESEARCH = "2", TOTAL = "3", NONPAYMENT = "4", EXIT = "5";
}

//���� ����
public class IntraService implements ServerService { //implements ServerService
	static boolean isOwn = true;
	Socket sock;
	String ipAd;
	DataOutputStream out;
	DataInputStream in;
	String name;
	String msg="d";
	ExcelManager manager;
	TreeMap<String,ClassInfo> treeMap = new TreeMap<String,ClassInfo>();
	Scanner scan = new Scanner(System.in);
	
	
//	public static void main(String[] args) throws Exception {
//		
//	}
	
	//������
	IntraService(Socket sock, String ipAd,String name,ExcelManager manager) throws IOException{
		this.sock = sock;
		this.ipAd = ipAd;
		this.name = name;
		out = new DataOutputStream(new BufferedOutputStream(sock.getOutputStream()));
		in = new DataInputStream(sock.getInputStream());
		this.manager = manager;
		treeMap = ExcelManager.treeMap;
	}
	
	//
	public void run() {

		AutoMsg(name);
		
		try {
			
			end:while(true) {
				ViewMainMenu();
				
				String choice="";
				choice = in.readUTF();
				
				switch (choice) {
	            case MENUNUM1.SEARCH:
	               PlaySubMenu(name);
	               break;
	            case MENUNUM1.ASK:
	            	if(IntraService.isOwn) {
	            		IntraService.isOwn =false;
	            		runINBOUND();
	 	            }	
	            	else
	            		SendMessage("�ٸ� ����� ��� ���Դϴ�.");
	               
	            	break;
	            case MENUNUM1.EXIT:
	               out.writeUTF("Exit!!!!");
	               out.flush();
	               break end;
	            default:
	               try {
	                  throw new ChoiceException(choice);
	               } catch (ChoiceException e) {
	                  e.printStackTrace();
	                  SendMessage("�߸��� ����. �ٽ� ����");
	               }
	            }
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	//�ڵ� ���� �˸� �޽���
	public void AutoMsg(String name) {
	     // �����͵�� �����ؾ��ؿ�
	      // ExcelManager excelManager =new ExcelManager();
	      try {
	    	 String level = treeMap.get(name).getLevel();
	    	 out.writeUTF(manager.rankCalc());
	         out.writeUTF(level +"  "+ name + "�ȳ��ϼ���.");
	         // out.writeUTF("������ ������ : "+ �����̶� ���ᾲ~)
	         int pay = treeMap.get(name).getTotal();
	         
	         out.writeUTF("���� �����ݾ�: "+ pay + "�Դϴ�.");
	         out.flush();
	      } catch (IOException e) {
	         e.printStackTrace();
	      }
	}
	
	//MainMenu
	public void ViewMainMenu() {
		try {
			//System.out.println(out.hashCode());
			out.writeUTF(" 1.��ȸ\n 2.����\n 3.������");
			out.flush();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void PlaySubMenu(String name) {
		String select="";
		try {
			
			hole: while(true) {
				out.writeUTF("1.���� Ķ���� ����\n2.��¥ �˻�\n3.�� ���� �ݾ�\n4.�̳� �ݾ� Ȯ��\n5.������");
				out.flush();
				select = in.readUTF();
				switch(select){
				case SEARCHINFO_SELECT1.CALENDER:
					SendMessage(manager.clientPersonView(name));	
					break;
				case SEARCHINFO_SELECT1.DATESEARCH:
					SendMessage("������¥�� �Է��ϼ���");
					String day =ReceiveMessage();
					System.out.println("��¥ �Է� ���"+day);
					SendMessage(manager.clientDateView(name, day));
					break;
				case SEARCHINFO_SELECT1.NONPAYMENT:
					SendMessage(manager.clientNameSearchView(name));
					break;
				case SEARCHINFO_SELECT1.TOTAL:
					SendMessage("�ѳ��� �ݾ��� "+Integer.toString(manager.clientPenaltyReturn(name)));
					break;
				case SEARCHINFO_SELECT1.EXIT:
					break hole;
				default :
					 try {
		                  throw new ChoiceException(select);
		               } catch (ChoiceException e) {
		                  e.printStackTrace();
		                  SendMessage("�߸��� ����. �ٽ� ����");
		               }
					
				}
			}
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	class QuestMaker {
		private boolean marker = true;
		public boolean isMarker() {return marker;}
		public void setMarker(boolean marker) {this.marker = marker;}
		
	}
	
	private  void runINBOUND() {
		IntraService service;
		System.out.println(name+"�� �ιٿ�� ����");
		SendMessage("������ ���͵帱���?(close �Է½� ����)");
		String Answer ="";	
		QuestMaker marker = new QuestMaker();
		try {	
			new Thread(new Runnable() {	
		@Override
		public void run() {
		while(marker.isMarker()) {
			String Question = ReceiveMessage();
			System.out.println(name+"�� ���� : "+Question);
		
			if(Question.equals("close")) {
				IntraService.isOwn = true;
				marker.setMarker(false);
						}
							}
						}
					}).start();
		
		while (marker.isMarker()) {
			System.out.println(name+"���� �亯�� �Է��ϼ���");
			Answer = scan.nextLine(); 
			SendMessage(Answer);
			
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	//�޽��� ������
	public void SendMessage(String message) {		
		try {
			out.writeUTF(message);
			out.flush();
		    
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	//�޽��� �ޱ�
	@SuppressWarnings("finally")
	public String ReceiveMessage() {
		String receive ="";
		
		try {
			receive = in.readUTF();
		}catch(Exception e) {
			//System.out.println("����");
			e.printStackTrace();
		}finally {
			return receive;
		}
	}

}



