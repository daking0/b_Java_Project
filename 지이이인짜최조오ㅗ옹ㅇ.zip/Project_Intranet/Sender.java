package Project_Intranet;

import java.io.IOException;

public interface Sender {
	void send(String msg) throws IOException;
}