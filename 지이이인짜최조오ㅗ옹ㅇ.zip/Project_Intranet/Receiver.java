package Project_Intranet;

import java.io.IOException;

public interface Receiver {
	String receive() throws IOException;
}