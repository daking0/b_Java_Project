package Project_Intranet;

public interface SignTable {
	String end = "end";
	boolean on  = true;
	boolean off = false;
}
