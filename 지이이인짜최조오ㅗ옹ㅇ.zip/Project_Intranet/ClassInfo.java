package Project_Intranet;

import java.util.ArrayList;

public class ClassInfo {
   private String name;// �̸�
   private String ip;// ip�ּ�
   private int total;// �̳��ݾ�
   private int totalPayed; // ������� �� �ݾ�
   private int totalPenalty;// ��������� �� ����
   private ArrayList<DayInfo> toDayList;
   private String level;
   
   
   ClassInfo() {
      toDayList = new ArrayList<DayInfo>();
   }

   private void calcTotal() {
      total = totalPenalty-totalPayed;
   }

   void setTotal(int total) {
      this.total = total;
   }

   void setPayedTotal(int payedTotal) {
      this.totalPayed = payedTotal;
      calcTotal();
   }

   void setTotalPenalty(int penalty) {
      this.totalPenalty = penalty;
      calcTotal();
   }
   
   int getTotalPenalty() {
      return this.totalPenalty;
   }

   int getTotalPayed() {
      return this.totalPayed;
   }

   public int getTotal() {
      return total;
   }
   public void setLevel(String level) {
	   this.level = level;
   }
   public String getLevel() {
	   return level;
   }
   public void setName(String name) {
      this.name = name;
   }

   public String getName() {
      return name;
   }

   public void setIp(String ip) {
      this.ip = ip;
   }

   public String getIp() {
      return ip;
   }

   void clearArrayList() {
      toDayList = new ArrayList<DayInfo>();
   }

   public ArrayList<DayInfo> getArrList() {

      return toDayList;
   }

   void setArrayList(ArrayList<DayInfo> toDayList) {
      this.toDayList = toDayList;
   }

   void addArrayList(DayInfo dayInfo) {
      this.toDayList.add(dayInfo);
   }
//   void autoTotalPenaltyCalc() {
//	   int tmp =0;
//	   for(int i=0; i<toDayList.size();i++) {
//		   tmp +=toDayList.get(i).getPenalty();
//	   }
//	   this.totalPenalty = tmp;
//   }
//   void autoTotalPayedCalc() {
//	   int tmp =0;
//	   for(int i=0; i<toDayList.size();i++) {
//		   tmp +=toDayList.get(i).getPayed();
//	   }
//	   this.totalPenalty = tmp;
//   }

   //////
   public String clientDateView(String day) {
      String returnStr ="";
      for (int i = 0; i < getArrList().size(); i++) {

         if (getArrList().get(i).getDay().equals(day)) {
            if (getArrList().get(i).getPenalty() == 0) {
               returnStr +="�̳��ݾ��� �����ϴ�.";               
               break;
            } else if (getArrList().get(i).getPenalty() != 0)
               returnStr +=name + "����" + "" + "�������" + ":" + getArrList().get(i).getPenalty() + "�� �Դϴ�.";
               break;
         } 
         else if (i == getArrList().size()-1) {
            returnStr +="ã���ô� ��¥�� �����ϴ�. \n �߸� �Է� �ϼ̽��ϴ�.";
            break;
         }
      }
      return returnStr;
   }

   public String clientNameSearchView() {
      String returnStr = "";
      returnStr +=name + "���� " + "��  ���α���" + ":" + getTotalPayed() + "�� �Դϴ�.";
      returnStr +=name + "���� " + "�̳�����" + ":" + getTotal() + "�� �Դϴ�.";
      
      for (int i = 0; i < toDayList.size() - 1; i++) {
         if (toDayList.get(i).getPenalty() > 0) {
            returnStr +=name + "���� " + " " + "������ ����" + " " + toDayList.get(i).getDay() + "�Դϴ�.";
          
         }
      }
      return returnStr;
   }

   public String clientPenaltyAllView() {
      String returnStr ="";
      returnStr +=" name " + "       ip       ";
      
      for (int i = 0; i < toDayList.size(); i++) {
         if (toDayList.get(i).getPenalty() >= 1000) {
            returnStr +="|" + toDayList.get(i).getDay() + "|" + " ";
            
         }
      }
      returnStr +="\n";
      returnStr +=" " + name + " " + ip + "  ";
      
      for (int i = 0; i < toDayList.size(); i++) {

         if (toDayList.get(i).getPenalty() >= 1000) {
            if (toDayList.get(i).getPenalty() < 1000) {
               returnStr +="|  " + toDayList.get(i).getPenalty() + "    |" + " ";
               continue;
            }
            returnStr +="|  " + toDayList.get(i).getPenalty() + " |" + " ";
         }
      }
      returnStr +="\n";
      
      returnStr +="    �����񳳺� �ݾ�                         ";
      
      for (int i = 0; i < toDayList.size(); i++) {
         if (toDayList.get(i).getPenalty() >= 1000) {
            if (toDayList.get(i).getPayed() < 1000) {
               returnStr +="|  " + toDayList.get(i).getPayed() + "    |" + " ";
               continue;
            }
            returnStr +="|  " + toDayList.get(i).getPayed() + " |" + " ";
         }
      }
      returnStr +="\n";
      return returnStr;
   }

   public String clientPersonView() {
      String returnStr ="";
      returnStr +=" name " + "       ip       ";      
      for (int i = 0; i < toDayList.size(); i++) {
         returnStr +="|" + toDayList.get(i).getDay() + "|" + " ";
      }
      returnStr +="\n";
      returnStr +=" " + name + " " + ip + "  ";
      for (int i = 0; i < toDayList.size(); i++) {
         if (toDayList.get(i).getPenalty() < 1000) {
            returnStr +="|  " + toDayList.get(i).getPenalty() + "    |" + " ";
            continue;
         }
         returnStr +="|  " + toDayList.get(i).getPenalty() + " |" + " ";
         
      }
      returnStr +="\n";
      returnStr +="    ���� �ݾ�                         ";
      for (int i = 0; i < toDayList.size(); i++) {
         if (toDayList.get(i).getPayed() < 1000) {
            returnStr +="|  " + toDayList.get(i).getPayed() + "    |" + " ";
            continue;
         }
         returnStr +="|  " + toDayList.get(i).getPayed() + " |" + " ";
      }
      returnStr +="\n";
      
      return returnStr;
   }

   // ���� �Է� �޼���

   public void allShow() {
      System.out.print(name + " " + ip + " ");
      for (int i = 0; i < toDayList.size(); i++) {
         toDayList.get(i).showAll();
      }
      System.out.print(total + " ");
      System.out.print(totalPayed + " ");
      System.out.println();
   }

}

//���� Ŭ���� Array����Ʈ �ȿ� 2���� ����Ҹ� ����� ���ؼ� ����
class DayInfo extends ClassInfo{
   private String day;// ���� ��¥ ����
   private Integer penalty; // ������
   private int payed; // �� �ݾ�

   // getset ����

   public void setDay(String day) {
      this.day = day;
   }

   public void setpenalty(int penalty) {
      this.penalty = penalty;
   }

   public void setPayed(int payed) {
      this.payed = payed;
   }

   public String getDay() {
      return day;
   }

   public int getPenalty() {
      return penalty;
   }

   public int getPayed() {
      return payed;
   }

   public void showAll() {
      System.out.print(this.day + " : " + this.payed + " : " + this.penalty + " | ");
   }

   public String toString() {

      return day + " " + " " + penalty + " " + payed;
   }

}
//------ ���� Ŭ����DayInfo End--------------
//---------------------------------------