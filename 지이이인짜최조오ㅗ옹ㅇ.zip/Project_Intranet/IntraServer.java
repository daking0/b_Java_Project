package Project_Intranet;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Iterator;
import java.util.TreeMap;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class IntraServer implements ServerMain {
	int portNum ;
	//������
	ExcelManager manager ;
	 TreeMap<String, String> idMap;
	 
	IntraServer(int portNum){
		this.portNum = portNum;
		this.manager = new ExcelManager();
		this.idMap = setIdMap();
	}
	
	public static void main(String[] args) throws Exception {
		
		IntraServer server = new IntraServer(10002);
		server.Open();
		
	}
	
	//������ ����
	@Override
	public void Open() throws IOException {
		
		LogCreateThread logCreate = new LogCreateThread();
		ManagerThread managerThread = new ManagerThread(manager);
		ServerSocket server = new ServerSocket(portNum);
		System.out.println("������ ��ٸ��ϴ�.");
		managerThread.start();
		logCreate.start();
		while(true) {
			try {
			Socket sock = server.accept(); // ���� ����
			InetAddress inetaddr = sock.getInetAddress(); // ������ ���� ��
			String ipAd = inetaddr.getHostAddress(); // Ŭ���̾�Ʈ ip��
			String name =returnName(ipAd);
			
			System.out.println(name);
			IntraService intraMain = new IntraService(sock,ipAd,name,manager);
			System.out.println(ipAd);
							
				new Thread(intraMain).start(); //������ ����
			}catch(Exception e) {
				e.getStackTrace();
			}
			
			
		}
	}
	 //���� �ε�
	  public TreeMap<String, String> setIdMap() {
	      TreeMap<String, String> idMap = new TreeMap<String, String>();
	      try {
	         String name = "";
	         String ipAd = "";
	         FileInputStream file = new FileInputStream("Id.xls");
	         HSSFWorkbook workbook = new HSSFWorkbook(file);
	         HSSFSheet sheet = workbook.getSheetAt(0);

	         int row_count = sheet.getPhysicalNumberOfRows();
	         for (int rowIdx = 1; rowIdx < row_count; rowIdx++) {
	            HSSFRow row = sheet.getRow(rowIdx);
	            name = row.getCell(1).toString();
	            ipAd = row.getCell(2).toString();
	            idMap.put(ipAd, name);
	         }
	      } catch (IOException ex) {
	         System.out.println("id ��ȯ �Ϸ�");
	         ex.printStackTrace();
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      return idMap;
	   }
	   
	   //�̸� ã��
	   public String returnName(String ipAd) {
	      String name = "";
	      String ip = "";
	      int count = 0;
	
	      Iterator<String> it = idMap.keySet().iterator();

	      while (it.hasNext()) {
	         ip = it.next();
	         if (!(ip.equals(ip))) {
	            count++;
	            name = null;
	         } else if (ip.equals(ipAd)) {
	            name = idMap.get(ip);
	            break;
	         }
	      }
	      if (count == idMap.size())
	         System.out.println("ã���ô� ���̵� �����ϴ�.");
	      	return name;      
	   }

	@Override
	public void Close() {
		ExcelWriteClass write = new ExcelWriteClass();
		boolean end = true;
		write.writeExcel(end);
	}
}






