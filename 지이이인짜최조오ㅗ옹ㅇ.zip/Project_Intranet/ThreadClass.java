package Project_Intranet;

class LogCreateThread extends Thread {
	boolean endServer = false;
	@Override
	public void run() {
		
		while (true) {

			try {
				Thread.sleep(100000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Log ��� ���� ����  5���� �ٽ� �õ� �մϴ�.");
			}

			ExcelWriteClass excelwrite = new ExcelWriteClass();
			excelwrite.writeExcel(endServer);
		}
	}
}

public class ThreadClass {

}

class ManagerThread extends Thread {

	ExcelManager manager;

	ManagerThread(ExcelManager manager) {

		this.manager = manager;
	}
	@Override
	public void run() {
		while(true) {
			manager.adminMode();
		}
	}
}