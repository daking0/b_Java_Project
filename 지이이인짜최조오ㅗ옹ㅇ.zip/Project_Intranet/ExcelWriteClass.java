package Project_Intranet;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.TreeMap;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ExcelWriteClass {

	public static TreeMap<String, ClassInfo> hm = new TreeMap<String, ClassInfo>();

	private static String toDay() {
		Date d = new Date(System.currentTimeMillis());
		SimpleDateFormat sf = new SimpleDateFormat("yy"+"��"+"MM" + "��" + "dd" + "��"+"hh"+"��"+"mm"+"��"+"ss"+"��");
		String dt = sf.format(d);
		return dt;
	}
	protected void writeExcel(boolean end) {

		// ����� ��ü�� ����
		ClassInfo info0 = new ClassInfo();
		hm = ExcelManager.treeMap;

		HSSFWorkbook workbook = new HSSFWorkbook();// �� ���� ����

		HSSFSheet sheet0 = workbook.createSheet("������");
		HSSFSheet sheet1 = workbook.createSheet("���γ���");

		HSSFRow row0, row1;
		HSSFCell cell0, cell1;

		// ó�� �޴� ����

		row0 = sheet0.createRow(0);
		cell0 = row0.createCell(0);
		cell0.setCellValue("������ ����");

		row1 = sheet1.createRow(0);
		cell1 = row1.createCell(0);
		cell1.setCellValue("���� ����");

		int row_idx = 1;
		int cell_idx = 1;

		// HashMap�� ���� �ݺ�
		Iterator<String> it = hm.keySet().iterator();
		while (it.hasNext()) {
			cell_idx = 1;
			String pair = it.next();
			row0 = sheet0.createRow(row_idx);
			row1 = sheet1.createRow(row_idx);

			// ������ ��
		
				cell0 = row0.createCell(cell_idx);
				cell0.setCellValue(hm.get(pair).getName().toString());
				// ���� ��
				cell1 = row1.createCell(cell_idx);
				cell1.setCellValue(hm.get(pair).getName().toString());
				cell_idx++;

				cell0 = row0.createCell(cell_idx);
				cell0.setCellValue(hm.get(pair).getIp().toString());
				
				cell1 = row1.createCell(cell_idx);
				cell1.setCellValue(hm.get(pair).getIp().toString());
				cell_idx++;
				
			for (int i = 0; i < hm.get(pair).getArrList().size(); i++) {

				if (row_idx == 1) {

					cell0 = row0.createCell(cell_idx);
					cell0.setCellValue(hm.get(pair).getArrList().get(i).getDay());
					cell1 = row1.createCell(cell_idx);
					cell1.setCellValue(hm.get(pair).getArrList().get(i).getDay());
					cell_idx++;
				} else {
					cell0 = row0.createCell(cell_idx);
					cell0.setCellValue(hm.get(pair).getArrList().get(i).getPenalty());
					cell1 = row1.createCell(cell_idx);
					cell1.setCellValue(hm.get(pair).getArrList().get(i).getPayed());
					cell_idx++;
				}
			}
			if(row_idx==1) {
				cell0 = row0.createCell(hm.get(pair).getArrList().size() + 3);
				cell0.setCellValue("�� ������");
				
				cell1 = row1.createCell(hm.get(pair).getArrList().size() + 3);
				cell1.setCellValue("�� ������");
				
				cell0 = row0.createCell(hm.get(pair).getArrList().size() + 4);
				cell0.setCellValue("�̳��ݾ�");
			
				cell1 = row1.createCell(hm.get(pair).getArrList().size() + 4);
				cell1.setCellValue("���� �Ѿ�");
				
				row_idx++;
								
				
			}
			else if(row_idx>1){	
				
			cell0 = row0.createCell(hm.get(pair).getArrList().size() + 3);
			cell0.setCellValue(hm.get(pair).getTotalPenalty());
			
			cell1 = row1.createCell(hm.get(pair).getArrList().size() + 3);
			cell1.setCellValue(hm.get(pair).getTotalPenalty());
			
			cell0 = row0.createCell(hm.get(pair).getArrList().size() + 4);
			cell0.setCellValue(hm.get(pair).getTotal());
			cell1 = row1.createCell(hm.get(pair).getArrList().size() + 4);
			cell1.setCellValue(hm.get(pair).getTotalPayed());
			row_idx++;
			}
		}

		try {
			String tmpFileName= toDay();
			String fileName = "������DB.xls";
			
			if(end) {
			FileOutputStream fos = new FileOutputStream(fileName);
			workbook.write(fos);
			fos.close();
			System.out.println(fileName + "���� ���� ������ �����߽��ϴ�.");
			}
			else if(!end) { 
				FileOutputStream tmp = new FileOutputStream(tmpFileName+".xls");
			
			workbook.write(tmp);
			tmp.close();
			}
			
			System.out.println(tmpFileName+"log���� ���� ����");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("���� ������ ���� �Ͽ����ϴ�.");
		}
		
	}
	

}